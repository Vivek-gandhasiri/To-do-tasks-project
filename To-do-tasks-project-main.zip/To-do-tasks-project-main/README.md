# swecha__project_group3

# ClockIn

One of the biggest challenges that the covid pandemic introduced in our lives was a chain of never-ending meets and links making it extremely tedious to keep track of all the events. This is where our website ClockIn has come to the rescue. Using ClockIn the users can add events to the site and have a look at them when required.


## Website

The link for the website: https://yahshaswitha.github.io/swecha__project_group3/


## Tech Stack

- HTML
- CSS
- JS
  
  
## Creators

- Bachu Sai Venkata Nitin
- [Yahshaswitha Sirineni](https://github.com/yahshaswitha)
- Vachan Sai Kaki
- N Bhanu Prakash
- Tanya Kolanupaka
- Vemparala Yoshita Reddy
- Nalin Prabhath
- Lokesh Lavudya
- M jahnavi Reddy
- Sumith


"# To-do-tasks-project" 
"# To-do-tasks-project" 
